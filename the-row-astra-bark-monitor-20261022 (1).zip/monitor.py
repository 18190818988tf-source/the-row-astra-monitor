"""Lightweight The Row Astra restock monitor (stdlib only; no checkout).

Monitor only Shopify's public per-product JSON endpoint. An inaccessible or
ambiguous response is UNKNOWN, never silently treated as sold out/in stock.
"""
import json
import os
import re
import sys
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen

PRODUCT_URL = "https://www.therow.com/products/astra-black-ans-1"
HANDLE = "astra-black-ans-1"
STYLE = "W2164L117BLANS"
# Verified from the official public Shopify product JSON on 2026-10-22.
SKU = "W2164L117BLANS1SZ"
STATE_FILE = Path("state.json")
TIMEOUT = 20


def product_json_url(url=PRODUCT_URL):
    parsed = urlsplit(url)
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path.rstrip("/") + ".js", "", ""))


def parse_shopify(data):
    """Return (available|out_of_stock|unknown, reason) for exact Astra variant."""
    if not isinstance(data, dict) or data.get("handle") != HANDLE:
        return "unknown", "wrong product or missing exact product handle"
    variants = data.get("variants")
    if not isinstance(variants, list) or not variants:
        return "unknown", "missing product variants"
    matches = []
    for variant in variants:
        if not isinstance(variant, dict):
            continue
        sku = str(variant.get("sku") or "").strip().upper()
        # The site labels the style W2164L117BLANS but the Shopify variant
        # SKU is W2164L117BLANS1SZ. Match both size and color when using options.
        by_sku = sku == SKU
        by_options = (
            str(variant.get("option1") or "").strip().lower() == "black"
            and str(variant.get("option2") or "").strip().lower() == "one size"
            and str(variant.get("option3") or "").strip().upper() == STYLE
        )
        if by_sku or by_options:
            matches.append(variant)
    if len(matches) != 1:
        return "unknown", f"expected one exact Astra variant, found {len(matches)}"
    variant_available = matches[0].get("available")
    product_available = data.get("available")
    if type(variant_available) is not bool:
        return "unknown", "variant availability flag missing/not boolean"
    if type(product_available) is bool and product_available != variant_available:
        return "unknown", "product and variant availability flags disagree"
    return ("available" if variant_available else "out_of_stock"), "verified Shopify variant SKU"


def http_json(url):
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; AstraStockWatch/2.0; personal low-frequency check)",
        "Accept": "application/json",
        "Cache-Control": "no-cache",
    })
    with urlopen(req, timeout=TIMEOUT) as response:
        return json.load(response)


def check_stock():
    try:
        return parse_shopify(http_json(product_json_url()))
    except (HTTPError, URLError, TimeoutError, ValueError, TypeError, OSError) as exc:
        return "unknown", f"Shopify JSON unreachable: {type(exc).__name__}: {exc}"


def load_state():
    default = {"last_status": "unknown", "consecutive_errors": 0, "error_notified": False}
    if STATE_FILE.exists():
        try:
            state = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(state, dict):
                default.update({k: state[k] for k in default if k in state})
        except (OSError, ValueError):
            pass
    return default


def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def push(title, body, *, urgent=False):
    """Send a JSON push to the Bark device URL stored in GitHub Secrets.

    BARK_PUSH_URL is the complete private device URL copied from the Bark app:
    https://api.day.app/DEVICE_KEY (or an HTTPS self-hosted Bark endpoint).
    """
    push_url = os.getenv("BARK_PUSH_URL", "").strip().rstrip("/")
    parsed = urlsplit(push_url)
    if (parsed.scheme != "https" or not parsed.hostname or not parsed.path.strip("/")
            or parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("Configure a complete HTTPS BARK_PUSH_URL in GitHub Actions Secrets")

    payload = {
        "title": title,
        "body": body,
        "group": "The Row Astra 补货",
        "url": PRODUCT_URL,
        "level": "timeSensitive" if urgent else "active",
        "sound": "alarm" if urgent else "minuet",
    }
    request = Request(
        push_url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8",
                 "Accept": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=TIMEOUT) as response:
        if response.status not in (200, 201, 202, 204):
            raise RuntimeError(f"Bark returned HTTP {response.status}")
        raw_response = response.read(65536)
        if raw_response:
            try:
                decoded = json.loads(raw_response)
            except (ValueError, UnicodeDecodeError):
                # Some self-hosted Bark servers respond with plain text on success.
                decoded = {}
            if isinstance(decoded, dict) and "code" in decoded:
                if decoded["code"] not in (200,):
                    raise RuntimeError(f"Bark rejected the push (code={decoded['code']})")


def run():
    if "--test-push" in sys.argv or os.getenv("TEST_PUSH", "").lower() == "true":
        push("The Row Astra 监控测试", "Bark 测试成功，点击通知进入 The Row 商品页。")
        print("Bark test push sent; no stock check or state change")
        return

    state = load_state()
    status, reason = check_stock()
    print(f"The Row Astra {SKU}: status={status}; reason={reason}; previous={state['last_status']}")
    if status == "unknown":
        state["consecutive_errors"] = min(3, int(state["consecutive_errors"]) + 1)
        if state["consecutive_errors"] >= 3 and not state["error_notified"]:
            push("Astra 监控检查异常", "连续三次库存检查没有得到确定结果，请查看 GitHub Actions 运行日志。")
            state["error_notified"] = True
        save_state(state)
        return

    state["consecutive_errors"] = 0
    state["error_notified"] = False
    if status == "available" and state["last_status"] != "available":
        push("The Row Astra 已补货！", f"黑色 / One Size / {SKU} 已检测到可购买！点击立即进入商品页。", urgent=True)
        print("RESTOCK PUSH SENT")
    state["last_status"] = status
    save_state(state)


if __name__ == "__main__":
    run()
