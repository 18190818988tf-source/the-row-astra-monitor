# The Row Astra 补货监控 · Bark iPhone 推送版

**商品**：The Row Astra Bag，黑色 / One Size  
**商品链接**：https://www.therow.com/products/astra-black-ans-1  
**品牌款号**：`W2164L117BLANS`  
**官网 Shopify 实际变体 SKU**：`W2164L117BLANS1SZ`  
**查询地址**：https://www.therow.com/products/astra-black-ans-1.js

## 能做什么

- 由 GitHub Actions **计划每 5 分钟**查询一次官网的 Shopify 产品 JSON；GitHub 定时任务可能延迟、跳过，不能保证实时。
- 只判定 **黑色 / One Size / 准确 SKU** 的 `available` 布尔字段，不会把其他颜色误识别为补货。
- 确认补货时推送 iPhone **Bark** 通知，点击通知直接跳转商品页。
- 通过 `state.json` 避免每 5 分钟重复发送同一补货提醒。
- 连续 3 次查询无法确认库存，会发一次技术故障提醒。
- **不登录官网、不自动付款、不自动购买**。

## 一、将代码上传到 GitHub

仓库： https://github.com/18190818988tf-source/the-row-astra-monitor

### 推荐：Mac Terminal 一次上传整个文件夹

1. 下载并解压本 ZIP。解压后的文件夹名为 `the-row-astra-bark-monitor`。
2. 打开 Mac 的「终端」，输入 `cd `（`cd` 后有一个空格），把解压后的文件夹拖入终端窗口，回车。
3. 依次执行：

```bash
git init
git branch -M main
git add -A
git commit -m "Deploy The Row Astra Bark restock monitor"
git remote add origin https://github.com/18190818988tf-source/the-row-astra-monitor.git
git push -u origin main
```

若第一次提交显示 `Author identity unknown`，按终端提示配置 Git 用户名和邮箱（无需设置成公开邮箱）后再试。若认证弹出，使用 GitHub 官方登录流程；**不要把 GitHub 密码或 Token 发给任何人**。

也可以用 GitHub 网页上传，但务必保留 `.github/workflows/restock.yml` 的目录结构。macOS Finder 中可以通过 `Command + Shift + .` 显示隐藏的 `.github` 文件夹。

## 二、iPhone Bark 设置

1. 在 iPhone 安装 Bark：https://apps.apple.com/app/id1403753865
2. 打开 Bark，允许通知，找到 App 自带的 **推送测试 URL**。常见格式：`https://api.day.app/你的设备密钥`。
3. **完整 URL 是私密凭证**，只复制到 GitHub Secret 中，切勿写进代码仓库或分享给别人。
4. 打开： https://github.com/18190818988tf-source/the-row-astra-monitor/settings/secrets/actions
5. 点击 `New repository secret`，Name 填 `BARK_PUSH_URL`，Secret 填 **Bark App 提供的完整推送 URL**；保存。
6. 如果 Bark 使用自建服务器，也可以填写其 HTTPS 推送 URL。

## 三、测试 Bark 推送

1. 打开： https://github.com/18190818988tf-source/the-row-astra-monitor/actions/workflows/restock.yml
2. 点击 `Run workflow`，把 `test_push` 设为 `true`，运行。iPhone 应收到 Bark 测试消息；点击后打开该商品。
3. 再运行一遍，把 `test_push` 设为 `false`，查看 GitHub Actions 日志。现在缺货时一般会看到 `status=out_of_stock`；`unknown` 表示无法确定，并非缺货。
4. 检查 iPhone「设置 > 通知 > Bark」已经开启通知；时效性通知设置按需开启。

`state.json` 会在成功检查后由 GitHub Actions 自动更新。仓库 Settings > Actions > General > Workflow permissions 若未允许 `Read and write permissions`，需要开启写入权限，或核查仓库是否已有相应权限设置，否则去重状态将不能持久化。

## 其他说明

- 库存数据来自官网公开接口；2026-10-22 实际验证 `available=false`，但未来随时会变化。
- 每月理论触发约 8640 次，受 GitHub Actions 调度和限额制约。
- 如果商品只短暂补货，任何每 5 分钟扫描都可能错过；确认“有货”也不代表成功锁定库存。
- 当前 GitHub 仓库是**公开仓库**，代码本身无密钥。个人设备推送 URL 一定放进 GitHub Secrets。
- 本项目本地运行通过单元测试；真正的云端、Bark 手机通知必须在完成上传及配置后分别测试。

## 本地测试（可选）

```bash
python3 -m unittest discover -s tests -v
export BARK_PUSH_URL='https://api.day.app/你的设备密钥'
python3 monitor.py --test-push
python3 monitor.py
```
