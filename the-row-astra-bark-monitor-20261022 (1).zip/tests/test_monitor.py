import unittest
import json
import os
from unittest.mock import patch, MagicMock
import monitor


def product(in_stock=False, sku=monitor.SKU, variant_opts=True):
    v = {'sku': sku, 'available': in_stock}
    if variant_opts:
        v.update(option1='Black', option2='One Size', option3=monitor.STYLE)
    return {'handle': monitor.HANDLE, 'available': in_stock, 'variants': [v]}


class ShopifyParserTests(unittest.TestCase):
    def test_exact_variant_available(self):
        self.assertEqual(monitor.parse_shopify(product(True))[0], 'available')

    def test_exact_variant_unavailable(self):
        self.assertEqual(monitor.parse_shopify(product(False))[0], 'out_of_stock')

    def test_match_style_options_if_variant_sku_changes(self):
        self.assertEqual(monitor.parse_shopify(product(True, sku='OTHER'))[0], 'available')

    def test_do_not_match_different_style_even_with_one_variant(self):
        self.assertEqual(monitor.parse_shopify(product(True, sku='WRONG', variant_opts=False))[0], 'unknown')

    def test_wrong_handle_unknown(self):
        d = product(True)
        d['handle'] = 'astra-black-ans-3'
        self.assertEqual(monitor.parse_shopify(d)[0], 'unknown')

    def test_malformed_variants_unknown(self):
        d = product(True)
        d['variants'] = [None]
        self.assertEqual(monitor.parse_shopify(d)[0], 'unknown')

    def test_nonbool_flag_unknown(self):
        d = product(False)
        d['variants'][0]['available'] = 'false'
        self.assertEqual(monitor.parse_shopify(d)[0], 'unknown')

    def test_contradictory_flags_unknown(self):
        d = product(True)
        d['available'] = False
        self.assertEqual(monitor.parse_shopify(d)[0], 'unknown')

    def test_two_matching_variants_unknown(self):
        d = product(True)
        d['variants'].append(dict(d['variants'][0]))
        self.assertEqual(monitor.parse_shopify(d)[0], 'unknown')

    def test_endpoint(self):
        self.assertEqual(monitor.product_json_url(), monitor.PRODUCT_URL + '.js')

    @patch('monitor.http_json')
    def test_check_uses_public_product_json(self, mock_http):
        mock_http.return_value = product(False)
        self.assertEqual(monitor.check_stock()[0], 'out_of_stock')
        mock_http.assert_called_once_with(monitor.PRODUCT_URL + '.js')

    @patch('monitor.http_json')
    def test_network_failure_unknown_not_out_of_stock(self, mock_http):
        from urllib.error import URLError
        mock_http.side_effect = URLError('unreachable')
        self.assertEqual(monitor.check_stock()[0], 'unknown')


class BarkPushTests(unittest.TestCase):
    def test_requires_bark_secret(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ValueError):
                monitor.push("Test", "body")

    def test_bark_uses_json_and_clickable_product_link(self):
        from urllib.request import Request
        fake_response = MagicMock()
        fake_response.status = 200
        fake_response.read.return_value = b'{"code":200,"message":"success"}'
        fake_response.__enter__.return_value = fake_response
        with patch.dict(os.environ, {"BARK_PUSH_URL": "https://api.day.app/test_key"}):
            with patch('monitor.urlopen', return_value=fake_response) as transport:
                monitor.push("The Row Test", "Text body", urgent=True)
        req = transport.call_args.args[0]
        self.assertIsInstance(req, Request)
        self.assertEqual(req.full_url, "https://api.day.app/test_key")
        data = json.loads(req.data.decode('utf-8'))
        self.assertEqual(data['url'], monitor.PRODUCT_URL)
        self.assertEqual(data['title'], "The Row Test")
        self.assertEqual(data['level'], 'timeSensitive')
        self.assertEqual(data['group'], 'The Row Astra 补货')

    def test_bark_json_error_is_not_success(self):
        fake_response = MagicMock()
        fake_response.status = 200
        fake_response.read.return_value = b'{"code":400,"message":"invalid key"}'
        fake_response.__enter__.return_value = fake_response
        with patch.dict(os.environ, {"BARK_PUSH_URL": "https://api.day.app/test_key"}):
            with patch('monitor.urlopen', return_value=fake_response):
                with self.assertRaises(RuntimeError):
                    monitor.push("Test", "body")


if __name__ == '__main__':
    unittest.main()
